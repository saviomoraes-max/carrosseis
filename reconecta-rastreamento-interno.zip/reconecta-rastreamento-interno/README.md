# Rastreamento Interno RECONECTA — pacote de documentação

> Preparado em 2026-06-03. Projeto: construir um rastreador de atribuição de
> tráfego pago próprio (estilo UTMify), adaptado ao nosso caso de venda
> high-ticket, onde a conversão real é o **negócio ganho no Zoho** (dias depois),
> não um checkout instantâneo.

## O resumo em 30 segundos

Hoje a gente não consegue dizer com confiança **qual anúncio trouxe cada aluno
que fechou** — e portanto não sabe o **CAC real** por campanha. Ao olhar o Zoho a
fundo, descobrimos que os campos de origem **existem** no CRM, mas a captura
**parou de funcionar em ~08/janeiro/2026** (os campos saíram do layout). Nos
últimos 90 dias, **0 de 5.567 negócios novos** têm a origem gravada, e os **131
negócios ganhos** estão cegos. Além disso, mesmo quando funcionava, nunca
capturava os IDs de campanha nem o identificador que o Meta precisa pra otimizar.

A boa notícia: a correção é barata. O CRM já é, por desenho, o banco de
atribuição — não precisamos construir infraestrutura nova no primeiro momento. O
plano tem 5 passos, e o passo 1 (consertar a captura) já está especificado e em
implementação com o time de dev.

## O que tem neste pacote (ordem de leitura sugerida)

1. **utmify-clone-spec.md** — o documento principal. Explica em detalhe como uma
   ferramenta de rastreamento funciona, faz o inventário completo de
   funcionalidades, e especifica como construir a nossa versão interna casada com
   o nosso stack (Zoho, n8n, Meta). Inclui modelo de dados, arquitetura, roadmap
   em fases, riscos (LGPD etc.) e o que falta validar. *(é técnico e longo — as
   seções 1 e 7 são as mais estratégicas)*

2. **captura-atribuicao-v1.md** — o passo 1 do plano: como fazer toda nova venda
   voltar a registrar a origem do anúncio no CRM, com os IDs e o identificador do
   Meta que nunca foram capturados. Inclui o diagnóstico com os números reais.

3. **n8n-flow-atribuicao.md** — a solução técnica concreta acordada com o time de
   dev, depois de descobrirmos que a landing page já captura os dados. É o que
   está sendo implementado agora.

4. **snippets/** — o código pronto (o "motor" de parsing pro n8n e um script de
   captura de reserva pra landing pages futuras).

## Onde estamos e o que vem a seguir

- **Passo 1 — consertar a captura:** especificado e em implementação (dev).
  Critério de sucesso: 48h após subir, a cobertura de atribuição sai de ~0%.
- **Passo 2 — importar o gasto do Meta** por campanha (pode andar em paralelo).
- **Passo 3 — painel de CAC real / ROAS real / ciclo médio** por campanha.
- **Passo 4 — devolver a conversão pro Meta** (quando o negócio é ganho) pra
  algoritmo passar a otimizar por quem vira aluno de verdade, não por lead barato.
- **Passo 5 (opcional, futuro):** rastreamento de clique fora do CRM.
